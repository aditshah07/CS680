package edu.umb.cs.cs680.hw04;

public class InsufficientFundsException extends Exception{

  public InsufficientFundsException(String message) {
    super(message);
  }
}