package edu.umb.cs.cs680.hw02;
public interface State {

   void openCloseButtonPushed();

   void playButtonPushed();
   
   void stopButtonPushed();
}