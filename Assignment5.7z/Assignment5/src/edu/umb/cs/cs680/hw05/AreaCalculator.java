package edu.umb.cs.cs680.hw05;

import java.awt.Point;
import java.util.ArrayList;

public interface AreaCalculator {

	public float getArea(ArrayList<Point> points) throws InsufficientPointsException;

}