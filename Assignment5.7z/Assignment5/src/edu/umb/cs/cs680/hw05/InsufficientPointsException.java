package edu.umb.cs.cs680.hw05;

@SuppressWarnings("serial")
public class InsufficientPointsException extends Exception{

  public InsufficientPointsException(String message) {
    super(message);
  }
  
}